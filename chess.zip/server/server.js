const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const cors = require('cors');

const app = express();
app.use(cors());

const server = http.createServer(app);
const io = new Server(server, {
  cors: {
    origin: '*',
    methods: ['GET', 'POST']
  }
});

// Store active game rooms
// Format: { roomCode: { hostSocketId, guestSocketId, hostName, guestName, moves: [] } }
const rooms = new Map();

// Generate unique 6-character room code
function generateRoomCode() {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let code = '';
  for (let i = 0; i < 6; i++) {
    code += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return code;
}

app.get('/', (req, res) => {
  res.send('♟️ Chess Multiplayer Socket.io Server is running!');
});

io.on('connection', (socket) => {
  console.log(`Player connected: ${socket.id}`);

  // Create Room
  socket.on('create_room', (data) => {
    const { hostName } = data || {};
    let roomCode = generateRoomCode();
    while (rooms.has(roomCode)) {
      roomCode = generateRoomCode();
    }

    rooms.set(roomCode, {
      roomCode,
      hostSocketId: socket.id,
      guestSocketId: null,
      hostName: hostName || 'White Player',
      guestName: null,
      moves: []
    });

    socket.join(roomCode);
    console.log(`Room created: ${roomCode} by ${hostName} (${socket.id})`);

    socket.emit('room_created', {
      roomCode,
      hostName: hostName || 'White Player'
    });
  });

  // Join Room
  socket.on('join_room', (data) => {
    const { roomCode, guestName } = data || {};
    const codeUpper = (roomCode || '').toUpperCase().trim();

    if (!rooms.has(codeUpper)) {
      socket.emit('error', { message: 'Room code not found.' });
      return;
    }

    const room = rooms.get(codeUpper);

    if (room.guestSocketId && room.guestSocketId !== socket.id) {
      socket.emit('error', { message: 'Room is already full.' });
      return;
    }

    room.guestSocketId = socket.id;
    room.guestName = guestName || 'Black Player';

    socket.join(codeUpper);
    console.log(`Player ${guestName} (${socket.id}) joined room: ${codeUpper}`);

    // Notify both players that game is ready
    io.to(codeUpper).emit('room_joined', {
      roomCode: codeUpper,
      hostName: room.hostName,
      guestName: room.guestName,
      isReady: true
    });
  });

  // Handle Chess Move
  socket.on('make_move', (data) => {
    const { roomCode, move, turn } = data || {};
    const codeUpper = (roomCode || '').toUpperCase().trim();

    if (rooms.has(codeUpper)) {
      const room = rooms.get(codeUpper);
      room.moves.push(move);

      // Broadcast move to everyone else in the room
      socket.to(codeUpper).emit('move_made', {
        move,
        turn,
        senderId: socket.id
      });
      console.log(`Move in ${codeUpper}: ${move}`);
    }
  });

  // Handle In-Game Chat Message
  socket.on('send_message', (data) => {
    const { roomCode, senderName, message } = data || {};
    const codeUpper = (roomCode || '').toUpperCase().trim();

    if (rooms.has(codeUpper)) {
      io.to(codeUpper).emit('receive_message', {
        senderId: socket.id,
        senderName: senderName || 'Player',
        message,
        timestamp: Date.now()
      });
    }
  });

  // Handle Disconnect
  socket.on('disconnect', () => {
    console.log(`Player disconnected: ${socket.id}`);

    // Find rooms where this socket was host or guest
    for (const [code, room] of rooms.entries()) {
      if (room.hostSocketId === socket.id || room.guestSocketId === socket.id) {
        socket.to(code).emit('player_disconnected', {
          message: 'Opponent disconnected from the game.'
        });
        rooms.delete(code);
        console.log(`Room ${code} closed due to player disconnect.`);
      }
    }
  });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`🚀 Chess Socket.io server running on port ${PORT}`);
});
