package com.example.viewmodel

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.audio.ChessSoundEffects
import com.example.database.AppDatabase
import com.example.database.GameRecordEntity
import com.example.database.GameRepository
import com.example.engine.ChessAI
import com.example.engine.ChessEngine
import com.example.model.*
import com.example.network.ChatMessage
import com.example.network.MultiplayerService
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class ChessViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: GameRepository

    private val _boardState = MutableStateFlow(BoardState())
    val boardState: StateFlow<BoardState> = _boardState.asStateFlow()

    private val _selectedPosition = MutableStateFlow<Position?>(null)
    val selectedPosition: StateFlow<Position?> = _selectedPosition.asStateFlow()

    private val _legalMoves = MutableStateFlow<List<Position>>(emptyList())
    val legalMoves: StateFlow<List<Position>> = _legalMoves.asStateFlow()

    private val _gameMode = MutableStateFlow(GameMode.VS_AI)
    val gameMode: StateFlow<GameMode> = _gameMode.asStateFlow()

    private val _aiDifficulty = MutableStateFlow(AIDifficulty.EASY)
    val aiDifficulty: StateFlow<AIDifficulty> = _aiDifficulty.asStateFlow()

    private val _userColor = MutableStateFlow(PieceColor.WHITE)
    val userColor: StateFlow<PieceColor> = _userColor.asStateFlow()

    private val _boardTheme = MutableStateFlow(BoardTheme.WOOD)
    val boardTheme: StateFlow<BoardTheme> = _boardTheme.asStateFlow()

    private val _isSoundEnabled = MutableStateFlow(true)
    val isSoundEnabled: StateFlow<Boolean> = _isSoundEnabled.asStateFlow()

    private val _isBoardFlipped = MutableStateFlow(false)
    val isBoardFlipped: StateFlow<Boolean> = _isBoardFlipped.asStateFlow()

    private val _whitePlayerName = MutableStateFlow("Player 1")
    val whitePlayerName: StateFlow<String> = _whitePlayerName.asStateFlow()

    private val _blackPlayerName = MutableStateFlow("AI Bot")
    val blackPlayerName: StateFlow<String> = _blackPlayerName.asStateFlow()

    val chatMessages: StateFlow<List<ChatMessage>> = MultiplayerService.chatMessagesFlow

    private var timerJob: Job? = null
    private var aiJob: Job? = null

    init {
        val dao = AppDatabase.getDatabase(application).gameDao()
        repository = GameRepository(dao)

        startNewGame(GameMode.VS_AI, AIDifficulty.EASY, PieceColor.WHITE)

        // Observe multiplayer incoming moves
        viewModelScope.launch {
            MultiplayerService.incomingMoveFlow.collect { moveStr ->
                if (_gameMode.value == GameMode.ONLINE_MULTIPLAYER) {
                    val currState = _boardState.value
                    if (currState.currentTurn != _userColor.value) {
                        // Deserialize and apply move
                        val fromPos = Position.fromAlgebraic(moveStr.substring(0, 2))
                        val toPos = Position.fromAlgebraic(moveStr.substring(2, 4))
                        if (fromPos != null && toPos != null) {
                            val piece = currState.getPiece(fromPos)
                            if (piece != null) {
                                val move = ChessMove(fromPos, toPos, piece, currState.getPiece(toPos))
                                applyMoveInternal(move)
                            }
                        }
                    }
                }
            }
        }
    }

    fun startNewGame(
        mode: GameMode,
        difficulty: AIDifficulty = AIDifficulty.EASY,
        userPieceColor: PieceColor = PieceColor.WHITE,
        initialTimeMinutes: Int = 10,
        incrementSec: Int = 0,
        wName: String = "White",
        bName: String = "Black"
    ) {
        timerJob?.cancel()
        aiJob?.cancel()

        _gameMode.value = mode
        _aiDifficulty.value = difficulty
        _userColor.value = userPieceColor
        _isBoardFlipped.value = (userPieceColor == PieceColor.BLACK)

        _whitePlayerName.value = when (mode) {
            GameMode.VS_AI -> if (userPieceColor == PieceColor.WHITE) "You" else difficulty.label
            GameMode.LOCAL_PASS_AND_PLAY -> wName
            GameMode.ONLINE_MULTIPLAYER -> wName
        }

        _blackPlayerName.value = when (mode) {
            GameMode.VS_AI -> if (userPieceColor == PieceColor.BLACK) "You" else difficulty.label
            GameMode.LOCAL_PASS_AND_PLAY -> bName
            GameMode.ONLINE_MULTIPLAYER -> bName
        }

        val initBoard = ChessEngine.createInitialBoard()
        val totalSecs = initialTimeMinutes * 60

        _boardState.value = BoardState(
            board = initBoard,
            currentTurn = PieceColor.WHITE,
            status = GameStatus.ACTIVE,
            whiteTimeSeconds = totalSecs,
            blackTimeSeconds = totalSecs,
            timeIncrementSeconds = incrementSec,
            isTimerActive = initialTimeMinutes > 0
        )

        _selectedPosition.value = null
        _legalMoves.value = emptyList()

        if (initialTimeMinutes > 0) {
            startTimer()
        }

        // Trigger AI if AI is White
        if (mode == GameMode.VS_AI && userPieceColor == PieceColor.BLACK) {
            triggerAIMoveIfNeeded()
        }
    }

    fun onSquareClicked(pos: Position) {
        val currState = _boardState.value
        if (currState.status == GameStatus.CHECKMATE ||
            currState.status == GameStatus.STALEMATE ||
            currState.status == GameStatus.RESIGNED ||
            currState.status == GameStatus.TIMEOUT
        ) return

        // If online mode, prevent moving on opponent's turn
        if (_gameMode.value == GameMode.ONLINE_MULTIPLAYER && currState.currentTurn != _userColor.value) return

        // If VS AI mode, prevent moving on AI's turn
        if (_gameMode.value == GameMode.VS_AI && currState.currentTurn != _userColor.value) return

        val selected = _selectedPosition.value

        if (selected == null) {
            // Select piece
            val piece = currState.getPiece(pos)
            if (piece != null && piece.color == currState.currentTurn) {
                _selectedPosition.value = pos
                _legalMoves.value = ChessEngine.getLegalMoves(currState, pos)
            }
        } else {
            // Check if clicking destination
            if (_legalMoves.value.contains(pos)) {
                val movingPiece = currState.getPiece(selected)!!

                // Pawn Promotion Check
                if (movingPiece.type == PieceType.PAWN && (pos.row == 0 || pos.row == 7)) {
                    _boardState.value = currState.copy(
                        pendingPromotion = PendingPromotion(selected, pos, movingPiece.color)
                    )
                    return
                }

                val move = ChessMove(
                    from = selected,
                    to = pos,
                    piece = movingPiece,
                    capturedPiece = currState.getPiece(pos)
                )
                executeMove(move)
            } else {
                // Re-select another piece or clear selection
                val piece = currState.getPiece(pos)
                if (piece != null && piece.color == currState.currentTurn) {
                    _selectedPosition.value = pos
                    _legalMoves.value = ChessEngine.getLegalMoves(currState, pos)
                } else {
                    _selectedPosition.value = null
                    _legalMoves.value = emptyList()
                }
            }
        }
    }

    fun onPromotionSelected(type: PieceType) {
        val currState = _boardState.value
        val promo = currState.pendingPromotion ?: return
        val piece = currState.getPiece(promo.from) ?: return

        val move = ChessMove(
            from = promo.from,
            to = promo.to,
            piece = piece,
            capturedPiece = currState.getPiece(promo.to),
            promotionPieceType = type
        )

        _boardState.value = currState.copy(pendingPromotion = null)
        executeMove(move)
    }

    private fun executeMove(move: ChessMove) {
        applyMoveInternal(move)

        // Broadcast if online
        if (_gameMode.value == GameMode.ONLINE_MULTIPLAYER) {
            val room = MultiplayerService.currentRoom.value
            if (room != null) {
                MultiplayerService.sendMove(room.roomCode, move.toSerializedString(), _boardState.value.currentTurn)
            }
        }
    }

    private fun applyMoveInternal(move: ChessMove) {
        val prevState = _boardState.value
        val newState = ChessEngine.applyMove(prevState, move)

        _boardState.value = newState
        _selectedPosition.value = null
        _legalMoves.value = emptyList()

        // Audio & Haptic feedback
        if (_isSoundEnabled.value) {
            val context = getApplication<Application>().applicationContext
            if (newState.status == GameStatus.CHECKMATE || newState.status == GameStatus.STALEMATE) {
                ChessSoundEffects.playGameOver(context)
            } else if (newState.status == GameStatus.CHECK) {
                ChessSoundEffects.playCheck(context)
            } else if (move.capturedPiece != null || move.isEnPassant) {
                ChessSoundEffects.playCapture(context)
            } else if (move.isCastling) {
                ChessSoundEffects.playCastle(context)
            } else {
                ChessSoundEffects.playMove(context)
            }
        }

        // Save game if finished
        if (newState.status == GameStatus.CHECKMATE ||
            newState.status == GameStatus.STALEMATE ||
            newState.status == GameStatus.RESIGNED
        ) {
            saveGameToHistory(newState)
        } else {
            triggerAIMoveIfNeeded()
        }
    }

    private fun triggerAIMoveIfNeeded() {
        if (_gameMode.value == GameMode.VS_AI && _boardState.value.currentTurn != _userColor.value) {
            aiJob?.cancel()
            aiJob = viewModelScope.launch {
                delay(600) // Realistic bot think delay
                val aiMove = ChessAI.findBestMove(_boardState.value, _aiDifficulty.value)
                if (aiMove != null) {
                    applyMoveInternal(aiMove)
                }
            }
        }
    }

    private fun startTimer() {
        timerJob?.cancel()
        timerJob = viewModelScope.launch {
            while (true) {
                delay(1000)
                val state = _boardState.value
                if (!state.isTimerActive ||
                    state.status == GameStatus.CHECKMATE ||
                    state.status == GameStatus.STALEMATE ||
                    state.status == GameStatus.RESIGNED
                ) break

                if (state.currentTurn == PieceColor.WHITE) {
                    val newTime = state.whiteTimeSeconds - 1
                    if (newTime <= 0) {
                        val finalState = state.copy(
                            whiteTimeSeconds = 0,
                            status = GameStatus.TIMEOUT,
                            winner = PieceColor.BLACK
                        )
                        _boardState.value = finalState
                        saveGameToHistory(finalState)
                        break
                    } else {
                        _boardState.value = state.copy(whiteTimeSeconds = newTime)
                    }
                } else {
                    val newTime = state.blackTimeSeconds - 1
                    if (newTime <= 0) {
                        val finalState = state.copy(
                            blackTimeSeconds = 0,
                            status = GameStatus.TIMEOUT,
                            winner = PieceColor.WHITE
                        )
                        _boardState.value = finalState
                        saveGameToHistory(finalState)
                        break
                    } else {
                        _boardState.value = state.copy(blackTimeSeconds = newTime)
                    }
                }
            }
        }
    }

    fun toggleBoardFlip() {
        _isBoardFlipped.value = !_isBoardFlipped.value
    }

    fun setTheme(theme: BoardTheme) {
        _boardTheme.value = theme
    }

    fun toggleSound() {
        _isSoundEnabled.value = !_isSoundEnabled.value
    }

    fun resignGame() {
        val currState = _boardState.value
        val winner = currState.currentTurn.opposite()
        val finalState = currState.copy(status = GameStatus.RESIGNED, winner = winner)
        _boardState.value = finalState
        saveGameToHistory(finalState)
    }

    fun sendChatMessage(text: String) {
        val room = MultiplayerService.currentRoom.value
        if (room != null) {
            val myName = if (_userColor.value == PieceColor.WHITE) _whitePlayerName.value else _blackPlayerName.value
            MultiplayerService.sendChatMessage(room.roomCode, myName, text)
        }
    }

    private fun saveGameToHistory(state: BoardState) {
        viewModelScope.launch {
            val resultText = when (state.status) {
                GameStatus.CHECKMATE -> if (state.winner == PieceColor.WHITE) "White Won" else "Black Won"
                GameStatus.RESIGNED -> if (state.winner == PieceColor.WHITE) "White Won (Resigned)" else "Black Won (Resigned)"
                GameStatus.TIMEOUT -> if (state.winner == PieceColor.WHITE) "White Won (Time)" else "Black Won (Time)"
                GameStatus.STALEMATE, GameStatus.DRAW_AGREED -> "Draw"
                else -> "Finished"
            }

            val sanList = state.movesHistory.map { it.san }.joinToString(", ")
            val entity = GameRecordEntity(
                gameMode = _gameMode.value.name,
                whitePlayerName = _whitePlayerName.value,
                blackPlayerName = _blackPlayerName.value,
                resultText = resultText,
                movesSanJoined = sanList,
                totalMovesCount = state.movesHistory.size,
                durationSeconds = 600 - state.whiteTimeSeconds
            )
            repository.saveGame(entity)
        }
    }
}
