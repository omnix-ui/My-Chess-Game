package com.example.model

enum class GameMode {
    LOCAL_PASS_AND_PLAY,
    VS_AI,
    ONLINE_MULTIPLAYER
}

enum class AIDifficulty(val label: String, val depth: Int) {
    EASY("Beginner (Casual)", 1),
    MEDIUM("Intermediate (Tactical)", 2),
    HARD("Grandmaster (Minimax)", 3),
    GEMINI("Gemini AI Master", 4)
}

enum class GameStatus {
    ACTIVE,
    CHECK,
    CHECKMATE,
    STALEMATE,
    RESIGNED,
    TIMEOUT,
    DRAW_AGREED
}

data class Player(
    val id: String,
    val name: String,
    val color: PieceColor,
    val isOnline: Boolean = true,
    val isAi: Boolean = false
)

data class PendingPromotion(
    val from: Position,
    val to: Position,
    val color: PieceColor
)

data class BoardState(
    val board: Array<Array<ChessPiece?>> = Array(8) { Array(8) { null } },
    val currentTurn: PieceColor = PieceColor.WHITE,
    val status: GameStatus = GameStatus.ACTIVE,
    val winner: PieceColor? = null,
    val enPassantTarget: Position? = null,
    val movesHistory: List<ChessMove> = emptyList(),
    val capturedPiecesWhite: List<ChessPiece> = emptyList(), // Captured BY White
    val capturedPiecesBlack: List<ChessPiece> = emptyList(), // Captured BY Black
    val whiteTimeSeconds: Int = 600, // Default 10 min
    val blackTimeSeconds: Int = 600,
    val timeIncrementSeconds: Int = 0,
    val isTimerActive: Boolean = false,
    val pendingPromotion: PendingPromotion? = null
) {
    fun getPiece(pos: Position): ChessPiece? {
        if (!pos.isValid()) return null
        return board[pos.row][pos.col]
    }

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false

        other as BoardState

        if (currentTurn != other.currentTurn) return false
        if (status != other.status) return false
        if (winner != other.winner) return false
        if (enPassantTarget != other.enPassantTarget) return false
        if (movesHistory != other.movesHistory) return false
        if (capturedPiecesWhite != other.capturedPiecesWhite) return false
        if (capturedPiecesBlack != other.capturedPiecesBlack) return false
        if (whiteTimeSeconds != other.whiteTimeSeconds) return false
        if (blackTimeSeconds != other.blackTimeSeconds) return false
        if (pendingPromotion != other.pendingPromotion) return false

        for (r in 0..7) {
            for (c in 0..7) {
                if (board[r][c] != other.board[r][c]) return false
            }
        }
        return true
    }

    override fun hashCode(): Int {
        var result = currentTurn.hashCode()
        result = 31 * result + status.hashCode()
        result = 31 * result + (winner?.hashCode() ?: 0)
        result = 31 * result + (enPassantTarget?.hashCode() ?: 0)
        result = 31 * result + movesHistory.hashCode()
        return result
    }
}
