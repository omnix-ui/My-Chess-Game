package com.example.model

data class ChessMove(
    val from: Position,
    val to: Position,
    val piece: ChessPiece,
    val capturedPiece: ChessPiece? = null,
    val isCastling: Boolean = false,
    val isEnPassant: Boolean = false,
    val promotionPieceType: PieceType? = null,
    val san: String = "",
    val timestamp: Long = System.currentTimeMillis()
) {
    fun toSerializedString(): String {
        val promStr = promotionPieceType?.symbol ?: ""
        return "${from.toAlgebraic()}${to.toAlgebraic()}${if (promStr.isNotEmpty()) "=$promStr" else ""}"
    }

    companion object {
        fun fromSerializedString(str: String, piece: ChessPiece, captured: ChessPiece? = null): ChessMove? {
            if (str.length < 4) return null
            val fromStr = str.substring(0, 2)
            val toStr = str.substring(2, 4)
            val from = Position.fromAlgebraic(fromStr) ?: return null
            val to = Position.fromAlgebraic(toStr) ?: return null
            
            var promType: PieceType? = null
            if (str.contains("=")) {
                val pChar = str.substringAfter("=").take(1).uppercase()
                promType = when (pChar) {
                    "Q" -> PieceType.QUEEN
                    "R" -> PieceType.ROOK
                    "B" -> PieceType.BISHOP
                    "N" -> PieceType.KNIGHT
                    else -> PieceType.QUEEN
                }
            }
            return ChessMove(
                from = from,
                to = to,
                piece = piece,
                capturedPiece = captured,
                promotionPieceType = promType
            )
        }
    }
}
