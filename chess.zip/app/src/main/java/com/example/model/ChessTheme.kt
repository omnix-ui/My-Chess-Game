package com.example.model

import androidx.compose.ui.graphics.Color

enum class BoardTheme(
    val title: String,
    val lightSquare: Color,
    val darkSquare: Color,
    val highlightSelected: Color,
    val highlightLegalMove: Color,
    val highlightLastMove: Color,
    val highlightCheck: Color,
    val boardBorder: Color
) {
    WOOD(
        title = "Classic Wood",
        lightSquare = Color(0xFFF0D9B5),
        darkSquare = Color(0xFFB58863),
        highlightSelected = Color(0x997B61FF),
        highlightLegalMove = Color(0x884CAF50),
        highlightLastMove = Color(0x66CDDC39),
        highlightCheck = Color(0x99F44336),
        boardBorder = Color(0xFF5D4037)
    ),
    EMERALD(
        title = "Emerald & Mint",
        lightSquare = Color(0xFFE2EFCB),
        darkSquare = Color(0xFF769656),
        highlightSelected = Color(0x992196F3),
        highlightLegalMove = Color(0x88FFEB3B),
        highlightLastMove = Color(0x778BC34A),
        highlightCheck = Color(0x99E91E63),
        boardBorder = Color(0xFF2E7D32)
    ),
    SLATE(
        title = "Modern Slate",
        lightSquare = Color(0xFFE0E6ED),
        darkSquare = Color(0xFF4A6572),
        highlightSelected = Color(0x99FF9800),
        highlightLegalMove = Color(0x8800BCD4),
        highlightLastMove = Color(0x6603A9F4),
        highlightCheck = Color(0x99FF5252),
        boardBorder = Color(0xFF263238)
    ),
    CYBERPUNK(
        title = "Cyber Neon",
        lightSquare = Color(0xFF2A2D3A),
        darkSquare = Color(0xFF13151C),
        highlightSelected = Color(0xBB00E5FF),
        highlightLegalMove = Color(0xAA76FF03),
        highlightLastMove = Color(0x88FF007F),
        highlightCheck = Color(0xCCFF1744),
        boardBorder = Color(0xFF00E5FF)
    ),
    MARBLE(
        title = "Marble & Onyx",
        lightSquare = Color(0xFFF5F5F5),
        darkSquare = Color(0xFF333333),
        highlightSelected = Color(0x999C27B0),
        highlightLegalMove = Color(0x88009688),
        highlightLastMove = Color(0x66FFC107),
        highlightCheck = Color(0x99D50000),
        boardBorder = Color(0xFF212121)
    )
}
