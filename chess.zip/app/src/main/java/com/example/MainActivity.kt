package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.model.GameMode
import com.example.model.PieceColor
import com.example.screens.*
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.ChessViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    val navController = rememberNavController()
                    val viewModel: ChessViewModel = viewModel()
                    val currentTheme by viewModel.boardTheme.collectAsState()

                    NavHost(
                        navController = navController,
                        startDestination = "home"
                    ) {
                        composable("home") {
                            HomeScreen(
                                currentTheme = currentTheme,
                                onSelectTheme = { theme -> viewModel.setTheme(theme) },
                                onStartVsAi = { difficulty, color, time ->
                                    viewModel.startNewGame(
                                        mode = GameMode.VS_AI,
                                        difficulty = difficulty,
                                        userPieceColor = color,
                                        initialTimeMinutes = time
                                    )
                                    navController.navigate("game")
                                },
                                onStartPassAndPlay = { time ->
                                    viewModel.startNewGame(
                                        mode = GameMode.LOCAL_PASS_AND_PLAY,
                                        userPieceColor = PieceColor.WHITE,
                                        initialTimeMinutes = time
                                    )
                                    navController.navigate("game")
                                },
                                onOpenMultiplayerLobby = {
                                    navController.navigate("multiplayer_lobby")
                                },
                                onOpenStatsHistory = {
                                    navController.navigate("stats_history")
                                }
                            )
                        }

                        composable("multiplayer_lobby") {
                            MultiplayerLobbyScreen(
                                onBack = { navController.popBackStack() },
                                onStartOnlineGame = { roomCode, color, hostName, guestName ->
                                    viewModel.startNewGame(
                                        mode = GameMode.ONLINE_MULTIPLAYER,
                                        userPieceColor = color,
                                        initialTimeMinutes = 10,
                                        wName = hostName,
                                        bName = guestName
                                    )
                                    navController.navigate("game")
                                }
                            )
                        }

                        composable("game") {
                            GameScreen(
                                viewModel = viewModel,
                                onBackToHome = {
                                    navController.navigate("home") {
                                        popUpTo("home") { inclusive = true }
                                    }
                                }
                            )
                        }

                        composable("stats_history") {
                            StatsAndHistoryScreen(
                                onBack = { navController.popBackStack() }
                            )
                        }
                    }
                }
            }
        }
    }
}
