package com.example.engine

import com.example.model.*

object ChessEngine {

    fun createInitialBoard(): Array<Array<ChessPiece?>> {
        val board = Array(8) { Array<ChessPiece?>(8) { null } }

        // Black Pieces
        board[0][0] = ChessPiece(PieceType.ROOK, PieceColor.BLACK)
        board[0][1] = ChessPiece(PieceType.KNIGHT, PieceColor.BLACK)
        board[0][2] = ChessPiece(PieceType.BISHOP, PieceColor.BLACK)
        board[0][3] = ChessPiece(PieceType.QUEEN, PieceColor.BLACK)
        board[0][4] = ChessPiece(PieceType.KING, PieceColor.BLACK)
        board[0][5] = ChessPiece(PieceType.BISHOP, PieceColor.BLACK)
        board[0][6] = ChessPiece(PieceType.KNIGHT, PieceColor.BLACK)
        board[0][7] = ChessPiece(PieceType.ROOK, PieceColor.BLACK)
        for (c in 0..7) {
            board[1][c] = ChessPiece(PieceType.PAWN, PieceColor.BLACK)
        }

        // White Pieces
        for (c in 0..7) {
            board[6][c] = ChessPiece(PieceType.PAWN, PieceColor.WHITE)
        }
        board[7][0] = ChessPiece(PieceType.ROOK, PieceColor.WHITE)
        board[7][1] = ChessPiece(PieceType.KNIGHT, PieceColor.WHITE)
        board[7][2] = ChessPiece(PieceType.BISHOP, PieceColor.WHITE)
        board[7][3] = ChessPiece(PieceType.QUEEN, PieceColor.WHITE)
        board[7][4] = ChessPiece(PieceType.KING, PieceColor.WHITE)
        board[7][5] = ChessPiece(PieceType.BISHOP, PieceColor.WHITE)
        board[7][6] = ChessPiece(PieceType.KNIGHT, PieceColor.WHITE)
        board[7][7] = ChessPiece(PieceType.ROOK, PieceColor.WHITE)

        return board
    }

    fun getLegalMoves(state: BoardState, from: Position): List<Position> {
        val piece = state.getPiece(from) ?: return emptyList()
        if (piece.color != state.currentTurn) return emptyList()

        val pseudoMoves = getPseudoLegalMoves(state, from)
        return pseudoMoves.filter { to ->
            val simulatedState = applyMove(state, ChessMove(from, to, piece, state.getPiece(to)), isSimulation = true)
            !isKingInCheck(simulatedState, piece.color)
        }
    }

    fun getAllLegalMoves(state: BoardState, color: PieceColor): List<ChessMove> {
        val moves = mutableListOf<ChessMove>()
        for (r in 0..7) {
            for (c in 0..7) {
                val pos = Position(r, c)
                val piece = state.getPiece(pos) ?: continue
                if (piece.color == color) {
                    val validTos = getLegalMoves(state, pos)
                    for (to in validTos) {
                        moves.add(
                            ChessMove(
                                from = pos,
                                to = to,
                                piece = piece,
                                capturedPiece = state.getPiece(to)
                            )
                        )
                    }
                }
            }
        }
        return moves
    }

    private fun getPseudoLegalMoves(state: BoardState, from: Position): List<Position> {
        val piece = state.getPiece(from) ?: return emptyList()
        val moves = mutableListOf<Position>()

        when (piece.type) {
            PieceType.PAWN -> getPawnMoves(state, from, piece, moves)
            PieceType.KNIGHT -> getKnightMoves(state, from, piece, moves)
            PieceType.BISHOP -> getSlidingMoves(state, from, piece, moves, arrayOf(Pair(-1, -1), Pair(-1, 1), Pair(1, -1), Pair(1, 1)))
            PieceType.ROOK -> getSlidingMoves(state, from, piece, moves, arrayOf(Pair(-1, 0), Pair(1, 0), Pair(0, -1), Pair(0, 1)))
            PieceType.QUEEN -> getSlidingMoves(state, from, piece, moves, arrayOf(Pair(-1, -1), Pair(-1, 1), Pair(1, -1), Pair(1, 1), Pair(-1, 0), Pair(1, 0), Pair(0, -1), Pair(0, 1)))
            PieceType.KING -> getKingMoves(state, from, piece, moves)
        }

        return moves
    }

    private fun getPawnMoves(state: BoardState, from: Position, piece: ChessPiece, moves: MutableList<Position>) {
        val dir = if (piece.color == PieceColor.WHITE) -1 else 1
        val startRow = if (piece.color == PieceColor.WHITE) 6 else 1

        // Single step forward
        val oneStep = Position(from.row + dir, from.col)
        if (oneStep.isValid() && state.getPiece(oneStep) == null) {
            moves.add(oneStep)

            // Double step forward
            if (from.row == startRow) {
                val twoStep = Position(from.row + (dir * 2), from.col)
                if (twoStep.isValid() && state.getPiece(twoStep) == null) {
                    moves.add(twoStep)
                }
            }
        }

        // Diagonal captures & En Passant
        val capCols = arrayOf(from.col - 1, from.col + 1)
        for (c in capCols) {
            val capPos = Position(from.row + dir, c)
            if (capPos.isValid()) {
                val target = state.getPiece(capPos)
                if (target != null && target.color != piece.color) {
                    moves.add(capPos)
                } else if (state.enPassantTarget == capPos) {
                    moves.add(capPos)
                }
            }
        }
    }

    private fun getKnightMoves(state: BoardState, from: Position, piece: ChessPiece, moves: MutableList<Position>) {
        val offsets = arrayOf(
            Pair(-2, -1), Pair(-2, 1), Pair(-1, -2), Pair(-1, 2),
            Pair(1, -2), Pair(1, 2), Pair(2, -1), Pair(2, 1)
        )
        for ((dr, dc) in offsets) {
            val target = Position(from.row + dr, from.col + dc)
            if (target.isValid()) {
                val occupant = state.getPiece(target)
                if (occupant == null || occupant.color != piece.color) {
                    moves.add(target)
                }
            }
        }
    }

    private fun getSlidingMoves(
        state: BoardState,
        from: Position,
        piece: ChessPiece,
        moves: MutableList<Position>,
        directions: Array<Pair<Int, Int>>
    ) {
        for ((dr, dc) in directions) {
            var currRow = from.row + dr
            var currCol = from.col + dc
            while (true) {
                val pos = Position(currRow, currCol)
                if (!pos.isValid()) break
                val occupant = state.getPiece(pos)
                if (occupant == null) {
                    moves.add(pos)
                } else {
                    if (occupant.color != piece.color) {
                        moves.add(pos)
                    }
                    break
                }
                currRow += dr
                currCol += dc
            }
        }
    }

    private fun getKingMoves(state: BoardState, from: Position, piece: ChessPiece, moves: MutableList<Position>) {
        val offsets = arrayOf(
            Pair(-1, -1), Pair(-1, 0), Pair(-1, 1),
            Pair(0, -1), Pair(0, 1),
            Pair(1, -1), Pair(1, 0), Pair(1, 1)
        )
        for ((dr, dc) in offsets) {
            val target = Position(from.row + dr, from.col + dc)
            if (target.isValid()) {
                val occupant = state.getPiece(target)
                if (occupant == null || occupant.color != piece.color) {
                    moves.add(target)
                }
            }
        }

        // Castling logic
        if (!piece.hasMoved && !isKingInCheck(state, piece.color)) {
            val backRow = if (piece.color == PieceColor.WHITE) 7 else 0

            // Kingside castling
            val rookKingside = state.getPiece(Position(backRow, 7))
            if (rookKingside != null && rookKingside.type == PieceType.ROOK && !rookKingside.hasMoved) {
                if (state.getPiece(Position(backRow, 5)) == null && state.getPiece(Position(backRow, 6)) == null) {
                    if (!isSquareAttacked(state, Position(backRow, 5), piece.color.opposite()) &&
                        !isSquareAttacked(state, Position(backRow, 6), piece.color.opposite())
                    ) {
                        moves.add(Position(backRow, 6))
                    }
                }
            }

            // Queenside castling
            val rookQueenside = state.getPiece(Position(backRow, 0))
            if (rookQueenside != null && rookQueenside.type == PieceType.ROOK && !rookQueenside.hasMoved) {
                if (state.getPiece(Position(backRow, 1)) == null &&
                    state.getPiece(Position(backRow, 2)) == null &&
                    state.getPiece(Position(backRow, 3)) == null
                ) {
                    if (!isSquareAttacked(state, Position(backRow, 3), piece.color.opposite()) &&
                        !isSquareAttacked(state, Position(backRow, 2), piece.color.opposite())
                    ) {
                        moves.add(Position(backRow, 2))
                    }
                }
            }
        }
    }

    fun isKingInCheck(state: BoardState, color: PieceColor): Boolean {
        val kingPos = findKing(state, color) ?: return false
        return isSquareAttacked(state, kingPos, color.opposite())
    }

    private fun findKing(state: BoardState, color: PieceColor): Position? {
        for (r in 0..7) {
            for (c in 0..7) {
                val piece = state.board[r][c]
                if (piece != null && piece.type == PieceType.KING && piece.color == color) {
                    return Position(r, c)
                }
            }
        }
        return null
    }

    fun isSquareAttacked(state: BoardState, square: Position, attackerColor: PieceColor): Boolean {
        // Pawn attacks
        val pawnDir = if (attackerColor == PieceColor.WHITE) 1 else -1 // Pawn moves backwards from square perspective
        val pawnAttacks = arrayOf(Position(square.row + pawnDir, square.col - 1), Position(square.row + pawnDir, square.col + 1))
        for (p in pawnAttacks) {
            if (p.isValid()) {
                val piece = state.getPiece(p)
                if (piece != null && piece.color == attackerColor && piece.type == PieceType.PAWN) return true
            }
        }

        // Knight attacks
        val knightOffsets = arrayOf(
            Pair(-2, -1), Pair(-2, 1), Pair(-1, -2), Pair(-1, 2),
            Pair(1, -2), Pair(1, 2), Pair(2, -1), Pair(2, 1)
        )
        for ((dr, dc) in knightOffsets) {
            val p = Position(square.row + dr, square.col + dc)
            if (p.isValid()) {
                val piece = state.getPiece(p)
                if (piece != null && piece.color == attackerColor && piece.type == PieceType.KNIGHT) return true
            }
        }

        // King attacks
        val kingOffsets = arrayOf(
            Pair(-1, -1), Pair(-1, 0), Pair(-1, 1),
            Pair(0, -1), Pair(0, 1),
            Pair(1, -1), Pair(1, 0), Pair(1, 1)
        )
        for ((dr, dc) in kingOffsets) {
            val p = Position(square.row + dr, square.col + dc)
            if (p.isValid()) {
                val piece = state.getPiece(p)
                if (piece != null && piece.color == attackerColor && piece.type == PieceType.KING) return true
            }
        }

        // Diagonal attacks (Bishop, Queen)
        val diagDirs = arrayOf(Pair(-1, -1), Pair(-1, 1), Pair(1, -1), Pair(1, 1))
        for ((dr, dc) in diagDirs) {
            var r = square.row + dr
            var c = square.col + dc
            while (true) {
                val p = Position(r, c)
                if (!p.isValid()) break
                val piece = state.getPiece(p)
                if (piece != null) {
                    if (piece.color == attackerColor && (piece.type == PieceType.BISHOP || piece.type == PieceType.QUEEN)) return true
                    break
                }
                r += dr
                c += dc
            }
        }

        // Straight attacks (Rook, Queen)
        val straightDirs = arrayOf(Pair(-1, 0), Pair(1, 0), Pair(0, -1), Pair(0, 1))
        for ((dr, dc) in straightDirs) {
            var r = square.row + dr
            var c = square.col + dc
            while (true) {
                val p = Position(r, c)
                if (!p.isValid()) break
                val piece = state.getPiece(p)
                if (piece != null) {
                    if (piece.color == attackerColor && (piece.type == PieceType.ROOK || piece.type == PieceType.QUEEN)) return true
                    break
                }
                r += dr
                c += dc
            }
        }

        return false
    }

    fun applyMove(state: BoardState, move: ChessMove, isSimulation: Boolean = false): BoardState {
        val newBoard = Array(8) { r -> Array(8) { c -> state.board[r][c] } }
        val movingPiece = state.getPiece(move.from) ?: return state

        var isEnPassant = false
        var capturedPiece = state.getPiece(move.to)
        var newEnPassantTarget: Position? = null
        var isCastling = false

        // En passant capture detection
        if (movingPiece.type == PieceType.PAWN && move.to == state.enPassantTarget) {
            isEnPassant = true
            val capturedPawnRow = if (movingPiece.color == PieceColor.WHITE) move.to.row + 1 else move.to.row - 1
            capturedPiece = newBoard[capturedPawnRow][move.to.col]
            newBoard[capturedPawnRow][move.to.col] = null
        }

        // Double pawn move sets en passant target
        if (movingPiece.type == PieceType.PAWN && Math.abs(move.from.row - move.to.row) == 2) {
            val targetRow = (move.from.row + move.to.row) / 2
            newEnPassantTarget = Position(targetRow, move.from.col)
        }

        // Castling execution
        if (movingPiece.type == PieceType.KING && Math.abs(move.from.col - move.to.col) == 2) {
            isCastling = true
            val backRow = move.from.row
            if (move.to.col == 6) { // Kingside
                val rook = newBoard[backRow][7]
                newBoard[backRow][7] = null
                newBoard[backRow][5] = rook?.copy(hasMoved = true)
            } else if (move.to.col == 2) { // Queenside
                val rook = newBoard[backRow][0]
                newBoard[backRow][0] = null
                newBoard[backRow][3] = rook?.copy(hasMoved = true)
            }
        }

        // Handle promotion
        val isPromotion = movingPiece.type == PieceType.PAWN && (move.to.row == 0 || move.to.row == 7)
        val finalPieceType = if (isPromotion && move.promotionPieceType != null) {
            move.promotionPieceType
        } else {
            movingPiece.type
        }

        // Update piece location
        newBoard[move.from.row][move.from.col] = null
        newBoard[move.to.row][move.to.col] = ChessPiece(finalPieceType, movingPiece.color, hasMoved = true)

        if (isSimulation) {
            return state.copy(board = newBoard)
        }

        // Calculate SAN
        val san = generateSAN(state, move, isCastling, isEnPassant, isPromotion, finalPieceType)

        // Captured lists
        val newCapturedWhite = state.capturedPiecesWhite.toMutableList()
        val newCapturedBlack = state.capturedPiecesBlack.toMutableList()
        if (capturedPiece != null) {
            if (movingPiece.color == PieceColor.WHITE) newCapturedWhite.add(capturedPiece)
            else newCapturedBlack.add(capturedPiece)
        }

        val nextTurn = state.currentTurn.opposite()
        var tempState = state.copy(
            board = newBoard,
            currentTurn = nextTurn,
            enPassantTarget = newEnPassantTarget,
            capturedPiecesWhite = newCapturedWhite,
            capturedPiecesBlack = newCapturedBlack
        )

        // Check turn status (check, checkmate, stalemate)
        val inCheck = isKingInCheck(tempState, nextTurn)
        val opponentLegalMoves = getAllLegalMoves(tempState, nextTurn)

        val newStatus: GameStatus
        var winner: PieceColor? = null

        if (opponentLegalMoves.isEmpty()) {
            if (inCheck) {
                newStatus = GameStatus.CHECKMATE
                winner = movingPiece.color
            } else {
                newStatus = GameStatus.STALEMATE
            }
        } else if (inCheck) {
            newStatus = GameStatus.CHECK
        } else {
            newStatus = GameStatus.ACTIVE
        }

        val finalMove = move.copy(
            capturedPiece = capturedPiece,
            isCastling = isCastling,
            isEnPassant = isEnPassant,
            san = san
        )

        return tempState.copy(
            status = newStatus,
            winner = winner,
            movesHistory = state.movesHistory + finalMove
        )
    }

    private fun generateSAN(
        state: BoardState,
        move: ChessMove,
        isCastling: Boolean,
        isEnPassant: Boolean,
        isPromotion: Boolean,
        promType: PieceType
    ): String {
        if (isCastling) {
            return if (move.to.col == 6) "O-O" else "O-O-O"
        }

        val piece = move.piece
        val sb = StringBuilder()

        if (piece.type != PieceType.PAWN) {
            sb.append(piece.type.symbol)
        }

        // Capture symbol
        val isCapture = state.getPiece(move.to) != null || isEnPassant
        if (isCapture) {
            if (piece.type == PieceType.PAWN) {
                sb.append(('a' + move.from.col))
            }
            sb.append("x")
        }

        sb.append(move.to.toAlgebraic())

        if (isPromotion) {
            sb.append("=").append(promType.symbol)
        }

        return sb.toString()
    }
}
