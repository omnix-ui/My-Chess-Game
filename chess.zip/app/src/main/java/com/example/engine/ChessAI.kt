package com.example.engine

import com.example.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

object ChessAI {

    suspend fun findBestMove(state: BoardState, difficulty: AIDifficulty): ChessMove? = withContext(Dispatchers.Default) {
        val color = state.currentTurn
        val legalMoves = ChessEngine.getAllLegalMoves(state, color)
        if (legalMoves.isEmpty()) return@withContext null

        when (difficulty) {
            AIDifficulty.EASY -> {
                // Pick capture if available, otherwise random
                val captures = legalMoves.filter { it.capturedPiece != null }
                if (captures.isNotEmpty() && Random.nextFloat() < 0.6f) {
                    captures.random()
                } else {
                    legalMoves.random()
                }
            }
            AIDifficulty.MEDIUM -> {
                // Shallow minimax + captures preference
                var bestMove: ChessMove = legalMoves.random()
                var bestEval = Int.MIN_VALUE

                for (move in legalMoves.shuffled()) {
                    val simState = ChessEngine.applyMove(state, move)
                    val eval = evaluateBoard(simState, color)
                    if (eval > bestEval) {
                        bestEval = eval
                        bestMove = move
                    }
                }
                bestMove
            }
            AIDifficulty.HARD, AIDifficulty.GEMINI -> {
                // Minimax with Alpha-Beta Pruning depth 3
                var bestMove: ChessMove? = null
                var bestEval = Int.MIN_VALUE
                var alpha = Int.MIN_VALUE
                val beta = Int.MAX_VALUE

                val sortedMoves = legalMoves.sortedByDescending { move ->
                    (move.capturedPiece?.type?.value ?: 0) * 10
                }

                for (move in sortedMoves) {
                    val simState = ChessEngine.applyMove(state, move)
                    val eval = minimax(simState, depth = 2, alpha = alpha, beta = beta, isMaximizing = false, aiColor = color)
                    if (eval > bestEval) {
                        bestEval = eval
                        bestMove = move
                    }
                    alpha = max(alpha, bestEval)
                }
                bestMove ?: legalMoves.random()
            }
        }
    }

    private fun minimax(
        state: BoardState,
        depth: Int,
        alpha: Int,
        beta: Int,
        isMaximizing: Boolean,
        aiColor: PieceColor
    ): Int {
        if (depth == 0 || state.status == GameStatus.CHECKMATE || state.status == GameStatus.STALEMATE) {
            return evaluateBoard(state, aiColor)
        }

        var currAlpha = alpha
        var currBeta = beta
        val currentTurn = state.currentTurn
        val legalMoves = ChessEngine.getAllLegalMoves(state, currentTurn)

        if (legalMoves.isEmpty()) {
            return evaluateBoard(state, aiColor)
        }

        if (isMaximizing) {
            var maxEval = Int.MIN_VALUE
            for (move in legalMoves) {
                val simState = ChessEngine.applyMove(state, move)
                val eval = minimax(simState, depth - 1, currAlpha, currBeta, false, aiColor)
                maxEval = max(maxEval, eval)
                currAlpha = max(currAlpha, eval)
                if (currBeta <= currAlpha) break
            }
            return maxEval
        } else {
            var minEval = Int.MAX_VALUE
            for (move in legalMoves) {
                val simState = ChessEngine.applyMove(state, move)
                val eval = minimax(simState, depth - 1, currAlpha, currBeta, true, aiColor)
                minEval = min(minEval, eval)
                currBeta = min(currBeta, eval)
                if (currBeta <= currAlpha) break
            }
            return minEval
        }
    }

    private fun evaluateBoard(state: BoardState, aiColor: PieceColor): Int {
        if (state.status == GameStatus.CHECKMATE) {
            return if (state.winner == aiColor) 10000 else -10000
        }
        if (state.status == GameStatus.STALEMATE) {
            return 0
        }

        var score = 0
        for (r in 0..7) {
            for (c in 0..7) {
                val piece = state.board[r][c] ?: continue
                val pieceVal = piece.type.value * 100
                val posVal = getPieceSquareBonus(piece.type, piece.color, r, c)
                val totalVal = pieceVal + posVal

                if (piece.color == aiColor) {
                    score += totalVal
                } else {
                    score -= totalVal
                }
            }
        }
        return score
    }

    private fun getPieceSquareBonus(type: PieceType, color: PieceColor, r: Int, c: Int): Int {
        val row = if (color == PieceColor.WHITE) r else 7 - r
        return when (type) {
            PieceType.PAWN -> pawnTable[row][c]
            PieceType.KNIGHT -> knightTable[row][c]
            PieceType.BISHOP -> bishopTable[row][c]
            PieceType.ROOK -> rookTable[row][c]
            PieceType.QUEEN -> 0
            PieceType.KING -> kingTable[row][c]
        }
    }

    // Positional evaluation tables
    private val pawnTable = arrayOf(
        intArrayOf(0,  0,  0,  0,  0,  0,  0,  0),
        intArrayOf(50, 50, 50, 50, 50, 50, 50, 50),
        intArrayOf(10, 10, 20, 30, 30, 20, 10, 10),
        intArrayOf(5,  5, 10, 25, 25, 10,  5,  5),
        intArrayOf(0,  0,  0, 20, 20,  0,  0,  0),
        intArrayOf(5, -5,-10,  0,  0,-10, -5,  5),
        intArrayOf(5, 10, 10,-20,-20, 10, 10,  5),
        intArrayOf(0,  0,  0,  0,  0,  0,  0,  0)
    )

    private val knightTable = arrayOf(
        intArrayOf(-50,-40,-30,-30,-30,-30,-40,-50),
        intArrayOf(-40,-20,  0,  0,  0,  0,-20,-40),
        intArrayOf(-30,  0, 10, 15, 15, 10,  0,-30),
        intArrayOf(-30,  5, 15, 20, 20, 15,  5,-30),
        intArrayOf(-30,  0, 15, 20, 20, 15,  0,-30),
        intArrayOf(-30,  5, 10, 15, 15, 10,  5,-30),
        intArrayOf(-40,-20,  0,  5,  5,  0,-20,-40),
        intArrayOf(-50,-40,-30,-30,-30,-30,-40,-50)
    )

    private val bishopTable = arrayOf(
        intArrayOf(-20,-10,-10,-10,-10,-10,-10,-20),
        intArrayOf(-10,  0,  0,  0,  0,  0,  0,-10),
        intArrayOf(-10,  0,  5, 10, 10,  5,  0,-10),
        intArrayOf(-10,  5,  5, 10, 10,  5,  5,-10),
        intArrayOf(-10,  0, 10, 10, 10, 10,  0,-10),
        intArrayOf(-10, 10, 10, 10, 10, 10, 10,-10),
        intArrayOf(-10,  5,  0,  0,  0,  0,  5,-10),
        intArrayOf(-20,-10,-10,-10,-10,-10,-10,-20)
    )

    private val rookTable = arrayOf(
        intArrayOf(0,  0,  0,  0,  0,  0,  0,  0),
        intArrayOf(5, 10, 10, 10, 10, 10, 10,  5),
        intArrayOf(-5,  0,  0,  0,  0,  0,  0, -5),
        intArrayOf(-5,  0,  0,  0,  0,  0,  0, -5),
        intArrayOf(-5,  0,  0,  0,  0,  0,  0, -5),
        intArrayOf(-5,  0,  0,  0,  0,  0,  0, -5),
        intArrayOf(-5,  0,  0,  0,  0,  0,  0, -5),
        intArrayOf(0,  0,  0,  5,  5,  0,  0,  0)
    )

    private val kingTable = arrayOf(
        intArrayOf(-30,-40,-40,-50,-50,-40,-40,-30),
        intArrayOf(-30,-40,-40,-50,-50,-40,-40,-30),
        intArrayOf(-30,-40,-40,-50,-50,-40,-40,-30),
        intArrayOf(-30,-40,-40,-50,-50,-40,-40,-30),
        intArrayOf(-20,-30,-30,-40,-40,-30,-30,-20),
        intArrayOf(-10,-20,-20,-20,-20,-20,-20,-10),
        intArrayOf(20, 20,  0,  0,  0,  0, 20, 20),
        intArrayOf(20, 30, 10,  0,  0, 10, 30, 20)
    )
}
