package com.example.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.ChessEngine
import com.example.model.*

@Composable
fun ChessBoardComponent(
    boardState: BoardState,
    theme: BoardTheme,
    selectedPosition: Position?,
    legalMoves: List<Position>,
    isFlipped: Boolean,
    onSquareClick: (Position) -> Unit,
    modifier: Modifier = Modifier
) {
    val lastMove = boardState.movesHistory.lastOrNull()
    val kingInCheckPos = remember(boardState) {
        if (boardState.status == GameStatus.CHECK || boardState.status == GameStatus.CHECKMATE) {
            findKingPosition(boardState, boardState.currentTurn)
        } else null
    }

    Box(
        modifier = modifier
            .aspectRatio(1f)
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .border(4.dp, theme.boardBorder, RoundedCornerShape(12.dp))
            .background(theme.boardBorder)
            .padding(2.dp)
            .testTag("board_container")
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            for (r in 0..7) {
                val row = if (isFlipped) 7 - r else r
                Row(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                ) {
                    for (c in 0..7) {
                        val col = if (isFlipped) 7 - c else c
                        val pos = Position(row, col)
                        val isLightSquare = (row + col) % 2 == 0
                        val isSelected = selectedPosition == pos
                        val isLegalMove = legalMoves.contains(pos)
                        val isLastMoveOrigin = lastMove?.from == pos
                        val isLastMoveDest = lastMove?.to == pos
                        val isCheckSquare = kingInCheckPos == pos

                        val squareColor = when {
                            isCheckSquare -> theme.highlightCheck
                            isSelected -> theme.highlightSelected
                            isLastMoveOrigin || isLastMoveDest -> theme.highlightLastMove
                            isLightSquare -> theme.lightSquare
                            else -> theme.darkSquare
                        }

                        val piece = boardState.getPiece(pos)

                        SquareView(
                            pos = pos,
                            piece = piece,
                            bgColor = squareColor,
                            isLightSquare = isLightSquare,
                            isLegalMove = isLegalMove,
                            hasPieceToCapture = isLegalMove && piece != null,
                            showRankLabel = c == 0,
                            showFileLabel = r == 7,
                            rankLabel = (8 - row).toString(),
                            fileLabel = ('a' + col).toString(),
                            theme = theme,
                            onClick = { onSquareClick(pos) },
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxHeight()
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SquareView(
    pos: Position,
    piece: ChessPiece?,
    bgColor: Color,
    isLightSquare: Boolean,
    isLegalMove: Boolean,
    hasPieceToCapture: Boolean,
    showRankLabel: Boolean,
    showFileLabel: Boolean,
    rankLabel: String,
    fileLabel: String,
    theme: BoardTheme,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val animatedColor by animateColorAsState(
        targetValue = bgColor,
        animationSpec = tween(durationMillis = 150),
        label = "squareColor"
    )

    val labelColor = if (isLightSquare) theme.darkSquare else theme.lightSquare

    Box(
        modifier = modifier
            .background(animatedColor)
            .clickable { onClick() }
            .testTag("square_r${pos.row}_c${pos.col}"),
        contentAlignment = Alignment.Center
    ) {
        // Rank label (Left edge)
        if (showRankLabel) {
            Text(
                text = rankLabel,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = labelColor.copy(alpha = 0.7f),
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(start = 2.dp, top = 1.dp)
            )
        }

        // File label (Bottom edge)
        if (showFileLabel) {
            Text(
                text = fileLabel,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = labelColor.copy(alpha = 0.7f),
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(end = 2.dp, bottom = 1.dp)
            )
        }

        // Legal Move Dot or Capture Ring
        if (isLegalMove) {
            if (hasPieceToCapture) {
                // Outer ring indicator for captures
                Box(
                    modifier = Modifier
                        .fillMaxSize(0.85f)
                        .border(3.dp, theme.highlightLegalMove, CircleShape)
                )
            } else {
                // Filled dot for simple move
                Box(
                    modifier = Modifier
                        .size(14.dp)
                        .clip(CircleShape)
                        .background(theme.highlightLegalMove)
                )
            }
        }

        // Piece Unicode Symbol
        if (piece != null) {
            val textColor = if (piece.color == PieceColor.WHITE) Color.White else Color(0xFF111111)
            val strokeColor = if (piece.color == PieceColor.WHITE) Color(0xFF222222) else Color(0xFFEEEEEE)

            Box(contentAlignment = Alignment.Center) {
                // Subtle shadow/outline effect for high contrast
                Text(
                    text = piece.unicodeSymbol(),
                    fontSize = 32.sp,
                    color = strokeColor,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.scale(1.05f)
                )
                Text(
                    text = piece.unicodeSymbol(),
                    fontSize = 32.sp,
                    color = textColor,
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}

private fun findKingPosition(state: BoardState, color: PieceColor): Position? {
    for (r in 0..7) {
        for (c in 0..7) {
            val p = state.board[r][c]
            if (p != null && p.type == PieceType.KING && p.color == color) {
                return Position(r, c)
            }
        }
    }
    return null
}
