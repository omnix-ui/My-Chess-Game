package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ChessPiece
import com.example.model.PieceColor

@Composable
fun CapturedPiecesView(
    capturedByWhite: List<ChessPiece>,
    capturedByBlack: List<ChessPiece>,
    modifier: Modifier = Modifier
) {
    val whiteMaterial = capturedByWhite.sumOf { it.type.value }
    val blackMaterial = capturedByBlack.sumOf { it.type.value }
    val diff = whiteMaterial - blackMaterial

    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            .padding(horizontal = 12.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Black pieces captured BY White
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            Text(text = "White: ", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
            capturedByWhite.sortedBy { it.type.value }.forEach { piece ->
                Text(
                    text = piece.unicodeSymbol(),
                    fontSize = 18.sp,
                    color = Color.Black
                )
            }
            if (diff > 0) {
                Text(
                    text = " +$diff",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF4CAF50),
                    modifier = Modifier.padding(start = 4.dp)
                )
            }
        }

        // White pieces captured BY Black
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            if (diff < 0) {
                Text(
                    text = "+${-diff} ",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF4CAF50),
                    modifier = Modifier.padding(end = 4.dp)
                )
            }
            capturedByBlack.sortedBy { it.type.value }.forEach { piece ->
                Text(
                    text = piece.unicodeSymbol(),
                    fontSize = 18.sp,
                    color = Color.White
                )
            }
            Text(text = " :Black", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
