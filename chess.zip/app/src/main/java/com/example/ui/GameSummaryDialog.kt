package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.BoardState
import com.example.model.GameStatus
import com.example.model.PieceColor

@Composable
fun GameSummaryDialog(
    boardState: BoardState,
    whitePlayerName: String,
    blackPlayerName: String,
    onRematch: () -> Unit,
    onNewGame: () -> Unit,
    onReviewMoves: () -> Unit
) {
    val resultTitle = when (boardState.status) {
        GameStatus.CHECKMATE -> {
            val winnerName = if (boardState.winner == PieceColor.WHITE) whitePlayerName else blackPlayerName
            "Checkmate! $winnerName Wins! 🏆"
        }
        GameStatus.RESIGNED -> {
            val winnerName = if (boardState.winner == PieceColor.WHITE) whitePlayerName else blackPlayerName
            "$winnerName Wins by Resignation! 🏆"
        }
        GameStatus.TIMEOUT -> {
            val winnerName = if (boardState.winner == PieceColor.WHITE) whitePlayerName else blackPlayerName
            "Time Out! $winnerName Wins! ⏱️"
        }
        GameStatus.STALEMATE -> "Stalemate! Game Draw 🤝"
        GameStatus.DRAW_AGREED -> "Draw Agreed! 🤝"
        else -> "Game Finished"
    }

    Dialog(onDismissRequest = { /* Must select an action */ }) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = resultTitle,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(text = "Total Moves", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(
                            text = "${boardState.movesHistory.size}",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(text = "Captures", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(
                            text = "${boardState.capturedPiecesWhite.size + boardState.capturedPiecesBlack.size}",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                Button(
                    onClick = onRematch,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("Rematch 🔄", fontSize = 15.sp, fontWeight = FontWeight.Bold)
                }

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedButton(
                    onClick = onReviewMoves,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("Review Moves 🔍", fontSize = 15.sp)
                }

                Spacer(modifier = Modifier.height(8.dp))

                TextButton(
                    onClick = onNewGame,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Back to Main Menu", fontSize = 14.sp)
                }
            }
        }
    }
}
