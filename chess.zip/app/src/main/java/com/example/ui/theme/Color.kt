package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val DarkBg = Color(0xFF1C1B1F)
val DarkSurface = Color(0xFF2B2930)
val DarkSurfaceVariant = Color(0xFF49454F)
val PrimaryPurple = Color(0xFFD0BCFF)
val PrimaryContainerPurple = Color(0xFF381E72)
val OnPrimaryPurple = Color(0xFF381E72)
val OnPrimaryContainerPurple = Color(0xFFEADDFF)
val TextLight = Color(0xFFE6E1E5)
val TextMuted = Color(0xFFCAC4D0)
val DarkBorder = Color(0xFF49454F)
