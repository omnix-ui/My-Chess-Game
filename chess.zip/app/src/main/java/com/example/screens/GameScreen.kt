package com.example.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.*
import com.example.network.MultiplayerService
import com.example.ui.*
import com.example.viewmodel.ChessViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GameScreen(
    viewModel: ChessViewModel,
    onBackToHome: () -> Unit
) {
    val boardState by viewModel.boardState.collectAsState()
    val selectedPosition by viewModel.selectedPosition.collectAsState()
    val legalMoves by viewModel.legalMoves.collectAsState()
    val gameMode by viewModel.gameMode.collectAsState()
    val boardTheme by viewModel.boardTheme.collectAsState()
    val isSoundEnabled by viewModel.isSoundEnabled.collectAsState()
    val isBoardFlipped by viewModel.isBoardFlipped.collectAsState()
    val whitePlayerName by viewModel.whitePlayerName.collectAsState()
    val blackPlayerName by viewModel.blackPlayerName.collectAsState()
    val chatMessages by viewModel.chatMessages.collectAsState()

    var showChatDialog by remember { mutableStateOf(false) }
    var showResignConfirm by remember { mutableStateOf(false) }

    val topPlayerName = if (isBoardFlipped) whitePlayerName else blackPlayerName
    val topPlayerTime = if (isBoardFlipped) boardState.whiteTimeSeconds else boardState.blackTimeSeconds
    val topPlayerColor = if (isBoardFlipped) PieceColor.WHITE else PieceColor.BLACK

    val bottomPlayerName = if (isBoardFlipped) blackPlayerName else whitePlayerName
    val bottomPlayerTime = if (isBoardFlipped) boardState.blackTimeSeconds else boardState.whiteTimeSeconds
    val bottomPlayerColor = if (isBoardFlipped) PieceColor.BLACK else PieceColor.WHITE

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = when (gameMode) {
                                GameMode.VS_AI -> "Vs AI (${viewModel.aiDifficulty.value.label})"
                                GameMode.LOCAL_PASS_AND_PLAY -> "Pass & Play"
                                GameMode.ONLINE_MULTIPLAYER -> "Online Room"
                            },
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = if (boardState.status == GameStatus.CHECK) "⚠️ CHECK!" else "Turn: ${boardState.currentTurn.name}",
                            fontSize = 11.sp,
                            color = if (boardState.status == GameStatus.CHECK) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBackToHome) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    if (gameMode == GameMode.ONLINE_MULTIPLAYER) {
                        IconButton(onClick = { showChatDialog = true }) {
                            BadgedBox(
                                badge = {
                                    if (chatMessages.isNotEmpty()) {
                                        Badge { Text("${chatMessages.size}") }
                                    }
                                }
                            ) {
                                Icon(imageVector = Icons.Default.Chat, contentDescription = "In-game Chat")
                            }
                        }
                    }

                    IconButton(onClick = { viewModel.toggleBoardFlip() }) {
                        Icon(imageVector = Icons.Default.FlipToBack, contentDescription = "Flip Board")
                    }

                    IconButton(onClick = { viewModel.toggleSound() }) {
                        Icon(
                            imageVector = if (isSoundEnabled) Icons.Default.VolumeUp else Icons.Default.VolumeOff,
                            contentDescription = "Toggle Sound"
                        )
                    }

                    IconButton(onClick = { showResignConfirm = true }) {
                        Icon(imageVector = Icons.Default.Flag, contentDescription = "Resign", tint = MaterialTheme.colorScheme.error)
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 12.dp, vertical = 6.dp),
            verticalArrangement = Arrangement.SpaceBetween,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Opponent Timer (Top)
            if (boardState.isTimerActive) {
                ChessTimerView(
                    playerName = topPlayerName,
                    timeSeconds = topPlayerTime,
                    isActive = boardState.currentTurn == topPlayerColor,
                    color = topPlayerColor,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 6.dp)
                )
            }

            // Captured Pieces Bar
            CapturedPiecesView(
                capturedByWhite = boardState.capturedPiecesWhite,
                capturedByBlack = boardState.capturedPiecesBlack,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp)
            )

            // Main 8x8 Chess Board
            ChessBoardComponent(
                boardState = boardState,
                theme = boardTheme,
                selectedPosition = selectedPosition,
                legalMoves = legalMoves,
                isFlipped = isBoardFlipped,
                onSquareClick = { pos -> viewModel.onSquareClicked(pos) },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
            )

            // User Timer (Bottom)
            if (boardState.isTimerActive) {
                ChessTimerView(
                    playerName = bottomPlayerName,
                    timeSeconds = bottomPlayerTime,
                    isActive = boardState.currentTurn == bottomPlayerColor,
                    color = bottomPlayerColor,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 6.dp, bottom = 6.dp)
                )
            }

            // SAN Move History Row
            MoveHistoryView(
                moves = boardState.movesHistory,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
            )
        }

        // Pawn Promotion Modal
        if (boardState.pendingPromotion != null) {
            PromotionDialog(
                color = boardState.pendingPromotion!!.color,
                onSelectPiece = { type -> viewModel.onPromotionSelected(type) }
            )
        }

        // Game Finished Summary Modal
        if (boardState.status == GameStatus.CHECKMATE ||
            boardState.status == GameStatus.STALEMATE ||
            boardState.status == GameStatus.RESIGNED ||
            boardState.status == GameStatus.TIMEOUT
        ) {
            GameSummaryDialog(
                boardState = boardState,
                whitePlayerName = whitePlayerName,
                blackPlayerName = blackPlayerName,
                onRematch = {
                    viewModel.startNewGame(
                        mode = gameMode,
                        difficulty = viewModel.aiDifficulty.value,
                        userPieceColor = viewModel.userColor.value
                    )
                },
                onNewGame = onBackToHome,
                onReviewMoves = { /* Review mode active in history */ }
            )
        }

        // Resign Confirmation Dialog
        if (showResignConfirm) {
            AlertDialog(
                onDismissRequest = { showResignConfirm = false },
                title = { Text("Resign Match?") },
                text = { Text("Are you sure you want to forfeit this match?") },
                confirmButton = {
                    Button(
                        onClick = {
                            showResignConfirm = false
                            viewModel.resignGame()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                    ) {
                        Text("Resign Match")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showResignConfirm = false }) {
                        Text("Cancel")
                    }
                }
            )
        }

        // Chat Sheet
        if (showChatDialog) {
            InGameChatDialog(
                messages = chatMessages,
                myPlayerId = MultiplayerService.getMyPlayerId(),
                onSendMessage = { text -> viewModel.sendChatMessage(text) },
                onDismiss = { showChatDialog = false }
            )
        }
    }
}
