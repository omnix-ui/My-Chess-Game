package com.example.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AIDifficulty
import com.example.model.BoardTheme
import com.example.model.GameMode
import com.example.model.PieceColor

@Composable
fun HomeScreen(
    currentTheme: BoardTheme,
    onSelectTheme: (BoardTheme) -> Unit,
    onStartVsAi: (AIDifficulty, PieceColor, Int) -> Unit,
    onStartPassAndPlay: (Int) -> Unit,
    onOpenMultiplayerLobby: () -> Unit,
    onOpenStatsHistory: () -> Unit
) {
    var showAiDialog by remember { mutableStateOf(false) }
    var showLocalDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        // Hero Header Card
        Card(
            shape = RoundedCornerShape(24.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 20.dp),
            colors = CardDefaults.cardColors(containerColor = Color.Transparent)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        Brush.linearGradient(
                            colors = listOf(
                                MaterialTheme.colorScheme.primary,
                                MaterialTheme.colorScheme.tertiary
                            )
                        )
                    )
                    .padding(24.dp)
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "♔",
                            fontSize = 42.sp,
                            color = Color.White,
                            modifier = Modifier.padding(end = 12.dp)
                        )
                        Column {
                            Text(
                                text = "GRANDMASTER",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.ExtraBold,
                                letterSpacing = 2.sp,
                                color = Color.White.copy(alpha = 0.8f)
                            )
                            Text(
                                text = "Chess Master",
                                fontSize = 28.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "Real-time multiplayer, AI bot practice, and legal move validation.",
                        fontSize = 13.sp,
                        color = Color.White.copy(alpha = 0.9f)
                    )
                }
            }
        }

        // Mode Selection Title
        Text(
            text = "Game Modes",
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground,
            modifier = Modifier.padding(bottom = 12.dp)
        )

        // Game Mode Cards
        ModeCard(
            title = "Play vs AI Bot",
            subtitle = "Practice offline against Beginner, Tactical, or Minimax Bot",
            icon = Icons.Default.SmartToy,
            accentColor = Color(0xFF2196F3),
            onClick = { showAiDialog = true },
            testTag = "btn_play_ai"
        )

        Spacer(modifier = Modifier.height(12.dp))

        ModeCard(
            title = "Online Multiplayer",
            subtitle = "Create or join room code for real-time 2-player match",
            icon = Icons.Default.Public,
            accentColor = Color(0xFF4CAF50),
            onClick = onOpenMultiplayerLobby,
            testTag = "btn_play_online"
        )

        Spacer(modifier = Modifier.height(12.dp))

        ModeCard(
            title = "Local Pass & Play",
            subtitle = "Two players on the same phone screen with timer",
            icon = Icons.Default.People,
            accentColor = Color(0xFFFF9800),
            onClick = { showLocalDialog = true },
            testTag = "btn_pass_play"
        )

        Spacer(modifier = Modifier.height(24.dp))

        // Theme Customization Title
        Text(
            text = "Board Themes",
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground,
            modifier = Modifier.padding(bottom = 12.dp)
        )

        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(BoardTheme.entries.toTypedArray()) { theme ->
                val isSelected = theme == currentTheme
                Card(
                    onClick = { onSelectTheme(theme) },
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant
                    ),
                    modifier = Modifier
                        .width(130.dp)
                        .border(
                            width = if (isSelected) 2.dp else 0.dp,
                            color = if (isSelected) MaterialTheme.colorScheme.primary else Color.Transparent,
                            shape = RoundedCornerShape(16.dp)
                        )
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Row(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                        ) {
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .fillMaxHeight()
                                    .background(theme.lightSquare)
                            )
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .fillMaxHeight()
                                    .background(theme.darkSquare)
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = theme.title,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Stats & History Button
        OutlinedButton(
            onClick = onOpenStatsHistory,
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp)
        ) {
            Icon(imageVector = Icons.Default.History, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text("Match History & Statistics", fontSize = 15.sp)
        }
    }

    // AI Setup Modal Dialog
    if (showAiDialog) {
        AiSetupDialog(
            onDismiss = { showAiDialog = false },
            onConfirm = { difficulty, color, time ->
                showAiDialog = false
                onStartVsAi(difficulty, color, time)
            }
        )
    }

    // Local Pass & Play Setup Modal
    if (showLocalDialog) {
        LocalSetupDialog(
            onDismiss = { showLocalDialog = false },
            onConfirm = { time ->
                showLocalDialog = false
                onStartPassAndPlay(time)
            }
        )
    }
}

@Composable
private fun ModeCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    accentColor: Color,
    onClick: () -> Unit,
    testTag: String
) {
    Card(
        onClick = onClick,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        modifier = Modifier
            .fillMaxWidth()
            .testTag(testTag)
    ) {
        Row(
            modifier = Modifier
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(accentColor.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = accentColor,
                    modifier = Modifier.size(26.dp)
                )
            }

            Spacer(modifier = Modifier.width(16.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = subtitle,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                )
            }

            Icon(
                imageVector = Icons.Default.ChevronRight,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
            )
        }
    }
}

@Composable
private fun AiSetupDialog(
    onDismiss: () -> Unit,
    onConfirm: (AIDifficulty, PieceColor, Int) -> Unit
) {
    var selectedDifficulty by remember { mutableStateOf(AIDifficulty.EASY) }
    var selectedColor by remember { mutableStateOf(PieceColor.WHITE) }
    var selectedTimeMinutes by remember { mutableStateOf(10) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Setup Practice vs AI") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                // Difficulty
                Text("Difficulty", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Column {
                    AIDifficulty.entries.forEach { diff ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { selectedDifficulty = diff }
                        ) {
                            RadioButton(
                                selected = selectedDifficulty == diff,
                                onClick = { selectedDifficulty = diff }
                            )
                            Text(diff.label, fontSize = 13.sp)
                        }
                    }
                }

                // Play as
                Text("Play As", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = selectedColor == PieceColor.WHITE,
                        onClick = { selectedColor = PieceColor.WHITE },
                        label = { Text("White (♔)") }
                    )
                    FilterChip(
                        selected = selectedColor == PieceColor.BLACK,
                        onClick = { selectedColor = PieceColor.BLACK },
                        label = { Text("Black (♚)") }
                    )
                }

                // Timer
                Text("Clock Mode", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    val times = listOf(5, 10, 15, 0)
                    times.forEach { t ->
                        FilterChip(
                            selected = selectedTimeMinutes == t,
                            onClick = { selectedTimeMinutes = t },
                            label = { Text(if (t == 0) "None" else "${t}m") }
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(onClick = { onConfirm(selectedDifficulty, selectedColor, selectedTimeMinutes) }) {
                Text("Start Match")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
private fun LocalSetupDialog(
    onDismiss: () -> Unit,
    onConfirm: (Int) -> Unit
) {
    var selectedTimeMinutes by remember { mutableStateOf(10) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Pass & Play Setup") },
        text = {
            Column {
                Text("Select Timer Per Player:", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Spacer(modifier = Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    val times = listOf(5, 10, 15, 0)
                    times.forEach { t ->
                        FilterChip(
                            selected = selectedTimeMinutes == t,
                            onClick = { selectedTimeMinutes = t },
                            label = { Text(if (t == 0) "None" else "${t}m") }
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(onClick = { onConfirm(selectedTimeMinutes) }) { Text("Start Match") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
