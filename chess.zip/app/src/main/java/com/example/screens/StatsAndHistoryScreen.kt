package com.example.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.database.AppDatabase
import com.example.database.GameRecordEntity
import com.example.engine.ChessEngine
import com.example.model.BoardState
import com.example.model.BoardTheme
import com.example.model.Position
import com.example.ui.ChessBoardComponent
import com.example.ui.MoveHistoryView
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StatsAndHistoryScreen(
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val dao = remember { AppDatabase.getDatabase(context).gameDao() }
    val gamesList by dao.getAllGameRecords().collectAsState(initial = emptyList())

    var selectedReplayGame by remember { mutableStateOf<GameRecordEntity?>(null) }

    val totalGames = gamesList.size
    val totalWins = gamesList.count { it.resultText.contains("Won", ignoreCase = true) }
    val winRate = if (totalGames > 0) (totalWins * 100) / totalGames else 0

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Statistics & History") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Stats Summary Card
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                StatMetricCard(
                    title = "Total Matches",
                    value = "$totalGames",
                    modifier = Modifier.weight(1f)
                )
                StatMetricCard(
                    title = "Wins",
                    value = "$totalWins",
                    modifier = Modifier.weight(1f)
                )
                StatMetricCard(
                    title = "Win Rate",
                    value = "$winRate%",
                    modifier = Modifier.weight(1f)
                )
            }

            Text(
                text = "Match History",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(top = 8.dp)
            )

            if (gamesList.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "No saved matches yet. Start playing!",
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(gamesList) { record ->
                        GameRecordItem(
                            record = record,
                            onClick = { selectedReplayGame = record }
                        )
                    }
                }
            }
        }

        // Replay Modal
        if (selectedReplayGame != null) {
            ReplayModal(
                record = selectedReplayGame!!,
                onDismiss = { selectedReplayGame = null }
            )
        }
    }
}

@Composable
private fun StatMetricCard(
    title: String,
    value: String,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(text = title, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = value, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        }
    }
}

@Composable
private fun GameRecordItem(
    record: GameRecordEntity,
    onClick: () -> Unit
) {
    val dateFormat = SimpleDateFormat("MMM dd, yyyy • HH:mm", Locale.getDefault())
    val dateStr = dateFormat.format(Date(record.dateTimestamp))

    Card(
        onClick = onClick,
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "${record.whitePlayerName} vs ${record.blackPlayerName}",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "${record.gameMode} • ${record.resultText}",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = "$dateStr • ${record.totalMovesCount} moves",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Icon(
                imageVector = Icons.Default.ChevronRight,
                contentDescription = "View Replay",
                tint = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun ReplayModal(
    record: GameRecordEntity,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.8f)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Match Analysis: ${record.resultText}",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )

                val movesSan = record.movesSanJoined.split(", ").filter { it.isNotBlank() }

                ChessBoardComponent(
                    boardState = BoardState(board = ChessEngine.createInitialBoard()),
                    theme = BoardTheme.WOOD,
                    selectedPosition = null,
                    legalMoves = emptyList(),
                    isFlipped = false,
                    onSquareClick = {},
                    modifier = Modifier.weight(1f)
                )

                Text(
                    text = "Moves: ${movesSan.joinToString(" ")}",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(vertical = 8.dp)
                )

                Button(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Close Replay")
                }
            }
        }
    }
}
