package com.example.screens

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.GameMode
import com.example.model.PieceColor
import com.example.network.MultiplayerService

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MultiplayerLobbyScreen(
    onBack: () -> Unit,
    onStartOnlineGame: (String, PieceColor, String, String) -> Unit
) {
    val context = LocalContext.current
    var hostName by remember { mutableStateOf("Player 1") }
    var joinCodeInput by remember { mutableStateOf("") }
    var selectedTimeMinutes by remember { mutableStateOf(10) }

    val currentRoom by MultiplayerService.currentRoom.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Online Rooms") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            if (currentRoom == null) {
                // Room Creation Section
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = "Create Match Room",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )

                        OutlinedTextField(
                            value = hostName,
                            onValueChange = { hostName = it },
                            label = { Text("Your Player Name") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )

                        Text("Time Control:", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            val times = listOf(5, 10, 15, 0)
                            times.forEach { t ->
                                FilterChip(
                                    selected = selectedTimeMinutes == t,
                                    onClick = { selectedTimeMinutes = t },
                                    label = { Text(if (t == 0) "None" else "${t}m") }
                                )
                            }
                        }

                        Button(
                            onClick = {
                                val code = MultiplayerService.createRoom(hostName)
                            },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("Create Room", fontSize = 15.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                // Join Room Section
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = "Join Room with Code",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.secondary
                        )

                        OutlinedTextField(
                            value = joinCodeInput,
                            onValueChange = { joinCodeInput = it.uppercase() },
                            label = { Text("Enter 4-6 Digit Room Code") },
                            placeholder = { Text("e.g. CHESS-8291") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )

                        Button(
                            onClick = {
                                if (joinCodeInput.isNotBlank()) {
                                    val success = MultiplayerService.joinRoom(joinCodeInput, hostName)
                                    if (success) {
                                        val room = MultiplayerService.currentRoom.value
                                        if (room != null) {
                                            onStartOnlineGame(
                                                room.roomCode,
                                                PieceColor.BLACK,
                                                room.hostName,
                                                hostName
                                            )
                                        }
                                    }
                                }
                            },
                            enabled = joinCodeInput.length >= 4,
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
                        ) {
                            Text("Join Room Match", fontSize = 15.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            } else {
                // Active Created Room View (Waiting for player)
                val room = currentRoom!!
                val isHost = room.hostPlayerId == MultiplayerService.getMyPlayerId()

                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .padding(24.dp)
                            .fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Text(
                            text = "Room Created!",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )

                        Text(
                            text = "Share this Room Code with your opponent:",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                        )

                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.surface,
                            modifier = Modifier.padding(vertical = 4.dp)
                        ) {
                            Text(
                                text = room.roomCode,
                                fontSize = 28.sp,
                                fontWeight = FontWeight.ExtraBold,
                                fontFamily = FontFamily.Monospace,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.padding(horizontal = 20.dp, vertical = 10.dp)
                            )
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            OutlinedButton(
                                onClick = {
                                    shareRoomCode(context, room.roomCode)
                                },
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(imageVector = Icons.Default.Share, contentDescription = null)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Share Invite")
                            }
                        }

                        HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

                        Text(
                            text = if (room.isGuestConnected) "Opponent Joined: ${room.guestName}" else "Waiting for second player to join...",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = if (room.isGuestConnected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onPrimaryContainer
                        )

                        Button(
                            onClick = {
                                onStartOnlineGame(
                                    room.roomCode,
                                    if (isHost) PieceColor.WHITE else PieceColor.BLACK,
                                    room.hostName,
                                    room.guestName ?: "Opponent"
                                )
                            },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("Launch Match Now ♟️", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        }

                        TextButton(
                            onClick = {
                                MultiplayerService.leaveRoom(room.roomCode)
                            }
                        ) {
                            Text("Cancel Room", color = MaterialTheme.colorScheme.error)
                        }
                    }
                }
            }
        }
    }
}

private fun shareRoomCode(context: Context, code: String) {
    val sendIntent: Intent = Intent().apply {
        action = Intent.ACTION_SEND
        putExtra(Intent.EXTRA_TEXT, "Play chess with me! Join my room using Code: $code")
        type = "text/plain"
    }
    val shareIntent = Intent.createChooser(sendIntent, "Invite Opponent to Chess")
    context.startActivity(shareIntent)
}
