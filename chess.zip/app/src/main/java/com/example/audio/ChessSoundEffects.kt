package com.example.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlin.math.sin

object ChessSoundEffects {

    private val scope = CoroutineScope(Dispatchers.Default)

    fun playMove(context: Context) {
        scope.launch {
            generateTone(freq = 440.0, durationMs = 50, volume = 0.4f)
            vibrate(context, 20)
        }
    }

    fun playCapture(context: Context) {
        scope.launch {
            generateToneSequence(
                freqs = doubleArrayOf(350.0, 600.0),
                durations = intArrayOf(40, 60),
                volume = 0.7f
            )
            vibrate(context, 45)
        }
    }

    fun playCheck(context: Context) {
        scope.launch {
            generateToneSequence(
                freqs = doubleArrayOf(880.0, 1100.0, 1320.0),
                durations = intArrayOf(70, 70, 100),
                volume = 0.8f
            )
            vibratePattern(context, longArrayOf(0, 50, 30, 80))
        }
    }

    fun playCastle(context: Context) {
        scope.launch {
            generateToneSequence(
                freqs = doubleArrayOf(523.25, 659.25),
                durations = intArrayOf(60, 80),
                volume = 0.6f
            )
            vibrate(context, 30)
        }
    }

    fun playGameOver(context: Context) {
        scope.launch {
            generateToneSequence(
                freqs = doubleArrayOf(523.25, 659.25, 783.99, 1046.50),
                durations = intArrayOf(100, 100, 100, 250),
                volume = 0.9f
            )
            vibratePattern(context, longArrayOf(0, 100, 50, 150))
        }
    }

    fun playClockTick(context: Context) {
        scope.launch {
            generateTone(freq = 1000.0, durationMs = 20, volume = 0.2f)
        }
    }

    private fun generateTone(freq: Double, durationMs: Int, volume: Float) {
        generateToneSequence(doubleArrayOf(freq), intArrayOf(durationMs), volume)
    }

    private fun generateToneSequence(freqs: DoubleArray, durations: IntArray, volume: Float) {
        try {
            val sampleRate = 22050
            var totalSamples = 0
            for (d in durations) totalSamples += (sampleRate * (d / 1000.0)).toInt()

            val buffer = ShortArray(totalSamples)
            var currentOffset = 0

            for (i in freqs.indices) {
                val freq = freqs[i]
                val durationMs = durations[i]
                val numSamples = (sampleRate * (durationMs / 1000.0)).toInt()

                for (j in 0 until numSamples) {
                    val time = j.toDouble() / sampleRate
                    val angle = 2.0 * Math.PI * freq * time
                    // Simple envelope fade out
                    val envelope = 1.0 - (j.toDouble() / numSamples)
                    val sample = (sin(angle) * Short.MAX_VALUE * volume * envelope).toInt().toShort()
                    if (currentOffset < totalSamples) {
                        buffer[currentOffset++] = sample
                    }
                }
            }

            val audioTrack = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_GAME)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sampleRate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(totalSamples * 2)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()

            audioTrack.write(buffer, 0, totalSamples)
            audioTrack.play()
        } catch (_: Exception) {
            // Fallback gracefully if audio fails
        }
    }

    private fun vibrate(context: Context, ms: Long) {
        try {
            val vibrator = getVibrator(context)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(ms)
            }
        } catch (_: Exception) {}
    }

    private fun vibratePattern(context: Context, timings: LongArray) {
        try {
            val vibrator = getVibrator(context)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createWaveform(timings, -1))
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(timings, -1)
            }
        } catch (_: Exception) {}
    }

    private fun getVibrator(context: Context): Vibrator? {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
            vibratorManager.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }
    }
}
