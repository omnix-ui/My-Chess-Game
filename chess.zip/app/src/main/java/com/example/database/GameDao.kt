package com.example.database

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface GameDao {

    @Query("SELECT * FROM game_records ORDER BY dateTimestamp DESC")
    fun getAllGameRecords(): Flow<List<GameRecordEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGameRecord(record: GameRecordEntity): Long

    @Query("DELETE FROM game_records WHERE id = :id")
    suspend fun deleteGameRecordById(id: Long)

    @Query("DELETE FROM game_records")
    suspend fun clearAllRecords()
}
