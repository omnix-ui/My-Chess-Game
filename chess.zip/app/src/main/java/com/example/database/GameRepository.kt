package com.example.database

import kotlinx.coroutines.flow.Flow

class GameRepository(private val gameDao: GameDao) {

    val allGames: Flow<List<GameRecordEntity>> = gameDao.getAllGameRecords()

    suspend fun saveGame(record: GameRecordEntity): Long {
        return gameDao.insertGameRecord(record)
    }

    suspend fun deleteGame(id: Long) {
        gameDao.deleteGameRecordById(id)
    }

    suspend fun clearHistory() {
        gameDao.clearAllRecords()
    }
}
