package com.example.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "game_records")
data class GameRecordEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val dateTimestamp: Long = System.currentTimeMillis(),
    val gameMode: String, // VS_AI, LOCAL_PASS_AND_PLAY, ONLINE_MULTIPLAYER
    val whitePlayerName: String,
    val blackPlayerName: String,
    val resultText: String, // White Won, Black Won, Draw
    val movesSanJoined: String, // Comma separated SAN moves
    val totalMovesCount: Int,
    val durationSeconds: Int
)
