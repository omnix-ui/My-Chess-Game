package com.example.network

import com.example.model.PieceColor
import io.socket.client.IO
import io.socket.client.Socket
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.util.UUID

data class ChatMessage(
    val id: String = UUID.randomUUID().toString(),
    val senderId: String,
    val senderName: String,
    val message: String,
    val timestamp: Long = System.currentTimeMillis()
)

data class RoomInfo(
    val roomCode: String,
    val hostPlayerId: String,
    val hostName: String,
    val guestPlayerId: String? = null,
    val guestName: String? = null,
    val isGuestConnected: Boolean = false,
    val lastMoveStr: String? = null,
    val currentTurnColor: PieceColor = PieceColor.WHITE,
    val isRematchRequestedByHost: Boolean = false,
    val isRematchRequestedByGuest: Boolean = false
)

object MultiplayerService {

    private const val SERVER_URL = "https://node-blank-omnix500omnix.replit.app"
    private var socket: Socket? = null

    private val scope = CoroutineScope(Dispatchers.IO)

    private val _currentRoom = MutableStateFlow<RoomInfo?>(null)
    val currentRoom: StateFlow<RoomInfo?> = _currentRoom

    private val _incomingMoveFlow = MutableSharedFlow<String>()
    val incomingMoveFlow: SharedFlow<String> = _incomingMoveFlow

    private val _chatMessagesFlow = MutableStateFlow<List<ChatMessage>>(emptyList())
    val chatMessagesFlow: StateFlow<List<ChatMessage>> = _chatMessagesFlow

    private var myPlayerId: String = UUID.randomUUID().toString().take(8)

    fun getMyPlayerId(): String = socket?.id() ?: myPlayerId

    init {
        initSocketConnection()
    }

    private fun initSocketConnection() {
        try {
            val opts = IO.Options().apply {
                forceNew = true
                reconnection = true
            }
            socket = IO.socket(SERVER_URL, opts)

            socket?.on(Socket.EVENT_CONNECT) {
                myPlayerId = socket?.id() ?: myPlayerId
            }

            socket?.on("room_created") { args ->
                if (args.isNotEmpty() && args[0] is JSONObject) {
                    val json = args[0] as JSONObject
                    val roomCode = json.optString("roomCode")
                    val hostName = json.optString("hostName")

                    val room = RoomInfo(
                        roomCode = roomCode,
                        hostPlayerId = getMyPlayerId(),
                        hostName = hostName,
                        isGuestConnected = false
                    )
                    _currentRoom.value = room
                    _chatMessagesFlow.value = emptyList()
                }
            }

            socket?.on("room_joined") { args ->
                if (args.isNotEmpty() && args[0] is JSONObject) {
                    val json = args[0] as JSONObject
                    val roomCode = json.optString("roomCode")
                    val hostName = json.optString("hostName")
                    val guestName = json.optString("guestName")
                    val isReady = json.optBoolean("isReady", true)

                    val existing = _currentRoom.value
                    val updated = RoomInfo(
                        roomCode = roomCode,
                        hostPlayerId = existing?.hostPlayerId ?: "host",
                        hostName = hostName,
                        guestPlayerId = "guest",
                        guestName = guestName,
                        isGuestConnected = isReady
                    )
                    _currentRoom.value = updated
                }
            }

            socket?.on("move_made") { args ->
                if (args.isNotEmpty() && args[0] is JSONObject) {
                    val json = args[0] as JSONObject
                    val move = json.optString("move")
                    val senderId = json.optString("senderId")

                    if (senderId != getMyPlayerId()) {
                        scope.launch {
                            _incomingMoveFlow.emit(move)
                        }
                    }
                }
            }

            socket?.on("receive_message") { args ->
                if (args.isNotEmpty() && args[0] is JSONObject) {
                    val json = args[0] as JSONObject
                    val senderId = json.optString("senderId")
                    val senderName = json.optString("senderName")
                    val message = json.optString("message")
                    val timestamp = json.optLong("timestamp", System.currentTimeMillis())

                    val newMsg = ChatMessage(
                        senderId = senderId,
                        senderName = senderName,
                        message = message,
                        timestamp = timestamp
                    )
                    _chatMessagesFlow.value = _chatMessagesFlow.value + newMsg
                }
            }

            socket?.on("player_disconnected") {
                val current = _currentRoom.value
                if (current != null) {
                    _currentRoom.value = current.copy(isGuestConnected = false)
                }
            }

            socket?.connect()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun createRoom(hostName: String): String {
        ensureConnected()
        val data = JSONObject().apply {
            put("hostName", hostName)
        }
        socket?.emit("create_room", data)
        return ""
    }

    fun joinRoom(code: String, guestName: String): Boolean {
        ensureConnected()
        val cleanCode = code.uppercase().trim()
        val data = JSONObject().apply {
            put("roomCode", cleanCode)
            put("guestName", guestName)
        }
        socket?.emit("join_room", data)
        return true
    }

    fun sendMove(roomCode: String, moveStr: String, nextTurn: PieceColor) {
        ensureConnected()
        val data = JSONObject().apply {
            put("roomCode", roomCode)
            put("move", moveStr)
            put("turn", nextTurn.name)
        }
        socket?.emit("make_move", data)
    }

    fun sendChatMessage(roomCode: String, senderName: String, text: String) {
        ensureConnected()
        val data = JSONObject().apply {
            put("roomCode", roomCode)
            put("senderName", senderName)
            put("message", text)
        }
        socket?.emit("send_message", data)
    }

    fun leaveRoom(roomCode: String) {
        _currentRoom.value = null
        _chatMessagesFlow.value = emptyList()
    }

    private fun ensureConnected() {
        if (socket == null || !socket!!.connected()) {
            initSocketConnection()
        }
    }
}
